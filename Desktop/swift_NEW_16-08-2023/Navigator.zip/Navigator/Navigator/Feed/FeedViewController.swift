//
//  FeedViewController.swift
//  Navigator
//
//  Created by Stanislav on 16.08.2023.
//

import UIKit

final class FeedViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemTeal
    }
}
